<?php
//database configurations
define("DB_HOST","localhost");
define("DB_UNAME","root");
define("DB_PASS","");
define("DB_DNAME","script");
$conn=mysqli_connect(DB_HOST,DB_UNAME,DB_PASS,DB_DNAME);
?>
