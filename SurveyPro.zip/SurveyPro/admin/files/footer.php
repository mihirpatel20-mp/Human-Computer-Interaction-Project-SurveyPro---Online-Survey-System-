  <footer class="footer">
    <div class="container-fluid">
      <div class="copyright">
  
        <script>
          
        </script> Made By: Mihir Patel
        
      </div>
    </div>
  </footer>
